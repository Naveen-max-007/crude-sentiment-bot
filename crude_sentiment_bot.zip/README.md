# Crude Sentiment Bot

Fetches crude oil-related news, analyzes sentiment, and sends trading signals via Telegram.